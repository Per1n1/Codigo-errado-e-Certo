package com.example.correcaocodigo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cleitoncodigoerrado.MyAdapter
import com.example.cleitoncodigoerrado.R


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.my_recycler_view)
        recyclerView.layoutManager = GridLayoutManager(this, 2)

        val data = listOf("Item 1", "Item 2", "Item 3", "Item 4", "Item 5")
        recyclerView.adapter = MyAdapter(data)
    }
}
